﻿Beat Between GitHub 一鍵上傳

1. 把這個 ZIP 完整解壓縮。
2. 雙擊 START_UPLOAD.cmd。
3. 若瀏覽器跳出 GitHub 登入／授權，登入 HHHHHOT 並允許。
4. 完成後會自動打開：https://github.com/HHHHHOT/Beat-Between

請不要直接在 ZIP 裡執行 START_UPLOAD.cmd，先解壓縮。
