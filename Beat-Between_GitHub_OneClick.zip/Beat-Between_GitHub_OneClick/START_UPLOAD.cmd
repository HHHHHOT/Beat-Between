﻿@echo off
chcp 65001 >nul
setlocal EnableExtensions
set "REPO=https://github.com/HHHHHOT/Beat-Between.git"
set "WEB=https://github.com/HHHHHOT/Beat-Between"
set "WORK=%TEMP%\Beat-Between-upload"
set "SRC=%~dp0payload"

title Beat Between - GitHub Upload

echo.
echo ================================================
echo   Beat Between - GitHub One-Click Upload
echo ================================================
echo.

echo [1/6] Checking Git...
where git >nul 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: Git was not found.
  echo Please reinstall Git for Windows, then run this file again.
  pause
  exit /b 1
)

if exist "%WORK%" rmdir /s /q "%WORK%"

echo [2/6] Cloning repository...
git clone "%REPO%" "%WORK%"
if errorlevel 1 (
  echo.
  echo ERROR: Could not clone the repository.
  echo Check that you are online and that this repository exists:
  echo %WEB%
  pause
  exit /b 1
)

echo [3/6] Copying manga and README...
if not exist "%WORK%\manga" mkdir "%WORK%\manga"
copy /y "%SRC%\manga\Beat_Between_EP1_Anchored_HQ.pdf" "%WORK%\manga\Beat_Between_EP1_Anchored_HQ.pdf" >nul
copy /y "%SRC%\README.md" "%WORK%\README.md" >nul

cd /d "%WORK%"

git config user.name "HHHHHOT"
git config user.email "HHHHHOT@users.noreply.github.com"

echo [4/6] Creating commit...
git add README.md manga/Beat_Between_EP1_Anchored_HQ.pdf
git diff --cached --quiet
if not errorlevel 1 (
  echo.
  echo Nothing to upload: GitHub already has this exact version.
  start "" "%WEB%"
  pause
  exit /b 0
)

git commit -m "Add Beat Between Episode 1 anchored HQ edition"
if errorlevel 1 (
  echo.
  echo ERROR: Could not create the commit.
  pause
  exit /b 1
)

echo [5/6] Uploading to GitHub...
echo.
echo If a GitHub sign-in window opens, sign in and approve it.
echo Do not close this window while authentication is in progress.
echo.
git push origin HEAD
if errorlevel 1 (
  echo.
  echo ERROR: Upload did not finish.
  echo If GitHub asked you to sign in, finish the sign-in and run START_UPLOAD.cmd again.
  pause
  exit /b 1
)

echo [6/6] Done!
echo.
echo Repository:
echo %WEB%
echo.
start "" "%WEB%"
pause
