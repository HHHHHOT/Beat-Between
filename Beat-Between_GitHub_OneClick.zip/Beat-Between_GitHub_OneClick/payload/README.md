# Beat Between｜《Beat之間》

## Introduction

《Beat之間》是一部以舞蹈、偶像團體與編舞老師為核心的黑白少女漫畫作品。

第一篇〈老師，妳真的懂我們嗎？〉描寫編舞老師彩第一次正式替四人團體 NOVA 排舞。她從舞蹈裡看見每個人的習慣，也第一次指出 rapper 流星「太在意拍點、太想被看見」的問題。

作品採用 90 年代後期日系少女漫畫的黑白線稿、網點與大格留白分鏡，並以手機直式閱讀節奏呈現。

## Read Episode 1

[閱讀第一篇・定錨版・高畫質完整版 PDF](manga/Beat_Between_EP1_Anchored_HQ.pdf)

## Characters

- 彩 Aya — 編舞老師。工作時認真嚴格，私下開朗有趣。
- 流星 Ryusei — NOVA rapper。拍感敏銳，但太習慣把每一拍踩得很滿。
- 仁 / 翔 / 凱 — NOVA 其他三名成員。

## Status

- Episode 1 — Anchored HQ Edition
- Episode 2 — In development
